package com.example.aulaquart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
